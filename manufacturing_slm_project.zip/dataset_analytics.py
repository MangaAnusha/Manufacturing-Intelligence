
import streamlit as st
import pandas as pd

@st.cache_data
def load_ai4i_dataset():
    return pd.read_csv("/content/manufacturing_slm/ai4i2020.csv")

def show_dataset_analytics():
    st.header("AI4I Predictive Maintenance Dataset")

    df = load_ai4i_dataset()

    total = len(df)
    failures = int(df["Machine failure"].sum())
    normal = total - failures

    c1, c2, c3 = st.columns(3)
    c1.metric("Total records", f"{total:,}")
    c2.metric("Normal records", f"{normal:,}")
    c3.metric("Failure records", f"{failures:,}")

    st.metric("Dataset failure rate", f"{failures / total * 100:.2f}%")

    st.subheader("Failure modes")
    modes = ["TWF", "HDF", "PWF", "OSF", "RNF"]
    mode_counts = df[modes].sum().astype(int)
    st.bar_chart(mode_counts)

    st.subheader("Sensor readings")
    sensor_cols = [
        "Air temperature",
        "Process temperature",
        "Rotational speed",
        "Torque",
        "Tool wear"
    ]

    selected_sensor = st.selectbox("Choose a sensor", sensor_cols)
    st.line_chart(df[selected_sensor].head(200))

    st.subheader("Dataset preview")
    st.dataframe(df.head(20), use_container_width=True)
